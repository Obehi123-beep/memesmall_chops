const slider = document.getElementById('imageSlider');
  let currentIndex = 0;  // Track the current index
  const totalImages = slider.children.length;
  const visibleImages = 10;  // Number of visible images at a time
  const imageWidth = 100 / visibleImages; // Each image occupies 10% of the width

  // Function to move the slider
  function moveSlider(direction) {
    // Calculate new index
    currentIndex += direction;
    
    // Loop around the images
    if (currentIndex < 0) {
      currentIndex = totalImages - visibleImages;
    } else if (currentIndex > totalImages - visibleImages) {
      currentIndex = 0;
    }

    // Move the slider by updating the transform property
    slider.style.transform = `translateX(-${currentIndex * imageWidth}%)`;
  }

  // Auto-slide functionality
  function autoSlide() {
    moveSlider(1);  // Move right by 1 set
  }

  // Start auto-sliding every 3 seconds
  setInterval(autoSlide, 3000);